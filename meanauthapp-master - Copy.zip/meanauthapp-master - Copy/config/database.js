module.exports = {
  //database: 'mongodb://brad:brad@ds121190.mlab.com:21190/meanauthapp',   //prod
  database: 'mongodb://localhost:27017/shopping',    //dev
  secret: 'yoursecret'
}
