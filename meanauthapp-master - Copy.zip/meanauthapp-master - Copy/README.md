# MEANauthapp

Complete MEAN stack application with authentication using json web tokens

### Version
1.0.0

## Usage


### Installation

Install the dependencies

```sh
$ npm install
```
Run app

```sh
$ npm start
```
