const express = require('express');
const router = express.Router();
const passport = require('passport');
const jwt = require('jsonwebtoken');
var UserController= require('../controllers/userController');

// Register
router.post('/register', UserController.Register);

// Authenticate
router.post('/authenticate',UserController.Authenticate);

// Profile
router.get('/profile', passport.authenticate('jwt', {session:false}), UserController.Profile);

module.exports = router;